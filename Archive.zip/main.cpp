// LED Marquee Totem
// Sasha Ramirez 2021

#include <Arduino.h>
#include <WiFi.h>

#include <FastLED.h>
#include <LEDMatrix.h>
#include <LEDText.h>
#include <FontMatrise.h>
#include <ESPAsyncWebServer.h>
#include <AsyncTCP.h>
#include <SPIFFS.h>
//#include <Arduino_JSON.h>
#include <arduinoFFT.h>


// FFT Init
#define SAMPLES 512              // Must be a power of 2
#define SAMPLING_FREQUENCY 40000 // Hz, must be 40000 or less due to ADC conversion time. Determines maximum frequency that can be analysed by the FFT Fmax=sampleF/2.
#define amplitude 200            // Depending on your audio source level, you may need to increase this value
unsigned int sampling_period_us;
unsigned long microseconds;
byte peak[] = {0,0,0,0,0,0,0};
double vReal[SAMPLES];
double vImag[SAMPLES];
unsigned long newTime, oldTime;

// Web Server Init
const char* ssid = "Marquee";
const char* password = "letsparty";
AsyncWebServer server(80);
AsyncWebSocket ws("/ws");

// Search for parameter in HTTP POST request
const char* PARAM_INPUT_1 = "inputColor1";
const char* PARAM_INPUT_2 = "inputColor2";
const char* PARAM_INPUT_3 = "brightness";
const char* PARAM_INPUT_4 = "inputString";
const char* PARAM_INPUT_5 = "colorMode";
const char* PARAM_INPUT_6 = "speed";
const char* PARAM_INPUT_7 = "reactivityMode";
const char* PARAM_INPUT_8 = "systemMode";

//Variables to save values from HTML form
String inputColor1,inputColor2, inputString, brightness, colorMode, speed, reactivityMode, systemMode;

bool newRequest = false;

uint messageSize = 110;
//LED Initialization

#define LED_PIN1        12
#define LED_PIN2        14
#define COLOR_ORDER    GRB
#define CHIPSET        WS2812B

#define MATRIX_WIDTH   60
#define MATRIX_HEIGHT  -7
#define MATRIX_TYPE    HORIZONTAL_ZIGZAG_MATRIX

cLEDMatrix<MATRIX_WIDTH, MATRIX_HEIGHT, MATRIX_TYPE> leds1;
cLEDMatrix<MATRIX_WIDTH, MATRIX_HEIGHT, MATRIX_TYPE> leds2;

cLEDText ScrollingMsg1;
cLEDText ScrollingMsg2;

String currentText;


unsigned char TxtDisplay[256] = {"            Wake up Neo...       The Matrix has you...      Follow the White Rabbit     Knock, knock, Neo.   "}; // 4 chars + null char

void notFound(AsyncWebServerRequest *request) {
  request->send(404, "text/plain", "Not found");
}

String readFile(fs::FS &fs, const char * path){
  //Serial.printf("Reading file: %s\r\n", path);
  File file = fs.open(path, "r");
  if(!file || file.isDirectory()){
    Serial.println("- empty file or failed to open file");
    return String();
  }
  //Serial.println("- read from file:");
  String fileContent;
  while(file.available()){
    fileContent+=String((char)file.read());
  }
  file.close();
  //Serial.println(fileContent);
  return fileContent;
}

void writeFile(fs::FS &fs, const char * path, const char * message){
  Serial.printf("Writing file: %s\r\n", path);
  File file = fs.open(path, "w+");
  if(!file){
    Serial.println("- failed to open file for writing");
    return;
  }
  if(file.print(message)){
    Serial.println("- file written");
  } else {
    Serial.println("- write failed");
  }
  file.close();
}

void setup() {
  Serial.begin(115200);

  //SPIFFS Setup
  if(!SPIFFS.begin(true)){
    Serial.println("An Error has occurred while mounting SPIFFS");
    return;
  }
  Serial.print("Setting soft access point mode");
  WiFi.softAP(ssid, password);
  IPAddress IP = WiFi.softAPIP();
  Serial.print("AP IP address: ");
  Serial.println(IP);

  // Web Server Root URL
  server.on("/", HTTP_GET, [](AsyncWebServerRequest *request){
    request->send(SPIFFS, "/index.html", "text/html");
  });
  
  server.serveStatic("/", SPIFFS, "/");

  server.on("/", HTTP_POST, [](AsyncWebServerRequest *request) {
    int params = request->params();
    for(int i=0;i<params;i++){
      AsyncWebParameter* p = request->getParam(i);
      if(p->isPost()){
        // HTTP POST input1 value
        if (p->name() == PARAM_INPUT_1) {
          inputColor1 = p->value().c_str();
          inputColor1.remove(0,1);
          Serial.print("Color: ");
          Serial.println(inputColor1);
        }
        // HTTP POST input1 value
        if (p->name() == PARAM_INPUT_2) {
          inputColor2 = p->value().c_str();
          inputColor2.remove(0,1);
          Serial.print("Color: ");
          Serial.println(inputColor2);
        }
        // HTTP POST input2 value
        if (p->name() == PARAM_INPUT_3) {
          brightness = p->value().c_str();
          Serial.print("Brightness: ");
          Serial.println(brightness);
          // Write file to save value
        }
        // HTTP POST input3 value
        if (p->name() == PARAM_INPUT_4) {
          inputString = p->value().c_str();
          Serial.print("Display Text: ");
          Serial.println(inputString);
          // Write file to save value
        }
        // HTTP POST input4 value
        if (p->name() == PARAM_INPUT_5) {
          colorMode = p->value().c_str();
          Serial.print("Color Mode: ");
          Serial.println(colorMode);
          // Write file to save value
        }
        // HTTP POST input3 value
        if (p->name() == PARAM_INPUT_6) {
          speed = p->value().c_str();
          Serial.print("Speed: ");
          Serial.println(speed);
          // Write file to save value
        }
        newRequest = true;
        //Serial.printf("POST[%s]: %s\n", p->name().c_str(), p->value().c_str());
      }
    }
    request->send(SPIFFS, "/index.html", "text/html");
  });
  server.onNotFound(notFound);
  server.begin();
  //LED Setup

  FastLED.addLeds<CHIPSET, LED_PIN1, COLOR_ORDER>(leds1[0], leds1.Size()).setCorrection(TypicalLEDStrip);
  FastLED.addLeds<CHIPSET, LED_PIN2, COLOR_ORDER>(leds2[0], leds2.Size()).setCorrection(TypicalLEDStrip);
  FastLED.setBrightness(64);
  FastLED.clear(true);
  delay(500);
  FastLED.show();
  ScrollingMsg1.SetFont(MatriseFontData);
  ScrollingMsg1.Init(&leds1, leds1.Width(), ScrollingMsg1.FontHeight() + 1, 0, 0);
  ScrollingMsg1.SetText((unsigned char *)TxtDisplay, messageSize);
  ScrollingMsg1.SetTextColrOptions(COLR_RGB | COLR_SINGLE, 0, 255, 0);
  ScrollingMsg1.SetFrameRate(2);
  ScrollingMsg2.SetFont(MatriseFontData);
  ScrollingMsg2.Init(&leds2, leds2.Width(), ScrollingMsg2.FontHeight() + 1, 0, 0);
  ScrollingMsg2.SetText((unsigned char *)TxtDisplay,messageSize);
  ScrollingMsg2.SetTextColrOptions(COLR_RGB | COLR_SINGLE, 0, 255, 0);
  ScrollingMsg2.SetFrameRate(2);
  

}
    
void loop() {

  if (ScrollingMsg1.UpdateText() == -1 || ScrollingMsg2.UpdateText() == -1){
     if (newRequest){
      char temp[2];

      temp[0] = (inputColor1.charAt(0));
      temp[1] = (inputColor1.charAt(1));
      uint8_t r1 = strtoul(temp,0,16);  
      
      temp[0] = (inputColor1.charAt(2));
      temp[1] = (inputColor1.charAt(3));
      uint8_t g1 = strtoul(temp,0,16);  

      temp[0] = (inputColor1.charAt(4));
      temp[1] = (inputColor1.charAt(5));
      uint8_t b1 = strtoul(temp,0,16);

      temp[0] = (inputColor2.charAt(0));
      temp[1] = (inputColor2.charAt(1));
      uint8_t r2 = strtoul(temp,0,16);  
      
      temp[0] = (inputColor2.charAt(2));
      temp[1] = (inputColor2.charAt(3));
      uint8_t g2 = strtoul(temp,0,16);  

      temp[0] = (inputColor2.charAt(4));
      temp[1] = (inputColor2.charAt(5));
      uint8_t b2 = strtoul(temp,0,16);

      if (colorMode == "CM1"){
        Serial.print("Color Mode 1");
        ScrollingMsg1.SetTextColrOptions(COLR_RGB | COLR_SINGLE, r1, g1, b1);
        ScrollingMsg2.SetTextColrOptions(COLR_RGB | COLR_SINGLE, r1, g1, b1);
      }
      else if (colorMode == "CM2"){
        Serial.print("Color Mode 2");
        ScrollingMsg1.SetTextColrOptions(COLR_RGB | COLR_GRAD_CV , r1, g1, b1, r2, g2, b2);
        ScrollingMsg2.SetTextColrOptions(COLR_RGB | COLR_GRAD_CV , r1, g1, b1, r2, g2, b2);
      }
      else if (colorMode == "CM3"){
        Serial.print("Color Mode 3");
        ScrollingMsg1.SetTextColrOptions(COLR_RGB | COLR_GRAD_AV, r1, g1, b1, r2, g2, b2);
        ScrollingMsg2.SetTextColrOptions(COLR_RGB | COLR_GRAD_CV , r1, g1, b1, r2, g2, b2);
      }      
      else if (colorMode == "CM4"){
        Serial.print("Color Mode 4");
        ScrollingMsg1.SetTextColrOptions(COLR_RGB | COLR_GRAD_CH, r1, g1, b1, r2, g2, b2);
        ScrollingMsg2.SetTextColrOptions(COLR_RGB | COLR_GRAD_CV , r1, g1, b1, r2, g2, b2);
      }
      else if (colorMode == "CM5"){
        Serial.print("Color Mode 5");
        ScrollingMsg1.SetTextColrOptions(COLR_RGB | COLR_GRAD_AH, r1, g1, b1, r2, g2, b2);
        ScrollingMsg2.SetTextColrOptions(COLR_RGB | COLR_GRAD_CV , r1, g1, b1, r2, g2, b2);
      }
      ScrollingMsg1.SetFrameRate(speed.toInt());
      ScrollingMsg2.SetFrameRate(speed.toInt());
      FastLED.setBrightness(brightness.toInt());
      newRequest = false;
      //Clear first
      memset(&TxtDisplay, 0, sizeof(TxtDisplay)-1);
      strcpy((char *)&TxtDisplay, inputString.c_str());
      messageSize = inputString.length();
      ScrollingMsg1.SetText((unsigned char *)TxtDisplay,messageSize);
      ScrollingMsg2.SetText((unsigned char *)TxtDisplay,messageSize);
      Serial.println(inputString.length());
     }
     else{
      ScrollingMsg1.SetText((unsigned char *)TxtDisplay, messageSize);
      ScrollingMsg2.SetText((unsigned char *)TxtDisplay, messageSize);
     }
  }

  else{
    FastLED.show();
  }
 delay(10);
}


// void spectrumMode(){
    
  // if(collectedSamples < NUM_FFT_SAMPLES)
	// return;

  // fft.Windowing(FFT_WIN_TYP_HANN, FFT_FORWARD);
  // fft.Compute(FFT_FORWARD);
  // fft.ComplexToMagnitude();

  // double maxi = getMax(&reals[0], TOTAL_DISP_COLS);
  // double mini = getMin(&reals[0], maxi, TOTAL_DISP_COLS);
 
  // for(int x = 0; x < TOTAL_DISP_COLS; x++)
  // {
	// int disp = (int)(x / NUM_DISP_COLUMNS);
	// int index = x;
	// int y = 0;

  //     // Ignore FFT results below the threshold
	// if(maxi > THRESHOLD)
  //          // Normalize the FFT result to be in the range [0,8]
  //     	y = (reals[index] - mini) * ((double)NUM_DISP_ROWS / maxi);

	// updateDisplay(disp, (x % NUM_DISP_COLUMNS), y);
	// oldValues[x] = y;
  // }

  // if(BAR_ANIMATION && (millis() - lastBarsUpdate) > BAR_UPDATE_DELAY)
  // {
	// updateBars();
	// lastBarsUpdate = millis();
  // }

  // // Re-enable sampling in the ISR
  // collectedSamples = 0;
// }

// void updateDisplay(int disp, int x, int y)
// {
//   // Get the column's old value from the array
//   double old = oldValues[(disp * NUM_DISP_COLUMNS) + x];

//   int d = NUM_DISPLAYS - disp - 1;

//   // The supplied column didn't change
//   if(old == y)
// 	return;
 
//   if(old < y)
//   {
// 	for(int led = old; led < y; led++)
//   	lc.setLed(d, led, NUM_DISP_COLUMNS - x - 1, true);
//   }
//   else
//   {
// 	for(int led = old; led >= y; led--)
//   	lc.setLed(d, led, NUM_DISP_COLUMNS - x - 1, false);
//   }
// }

// void updateBars(void)
// {
//   for(int i = 0; i < TOTAL_DISP_COLS; i++)
//   {
// 	int disp = NUM_DISPLAYS - (i / NUM_DISP_COLUMNS) - 1;
// 	int x = (i % NUM_DISP_COLUMNS);
    
// 	if(oldValues[i] < bars[i])
// 	{
//   	// Turn the current bar off
//   	lc.setLed(disp, bars[i], (NUM_DISP_COLUMNS - x - 1), false);

//   	// Decrease the bar counter for that column
//   	bars[i] = bars[i] - 1;

//   	// Turn the new bar on (if the level is still above 0)
//   	if(bars[i] >= 0)
//     	lc.setLed(disp, bars[i], (NUM_DISP_COLUMNS - x - 1), true);
// 	}
// 	else
// 	{
//   	bars[i] = oldValues[i];

//   	if(bars[i] == 0)
//     	lc.setLed(disp, bars[i], (NUM_DISP_COLUMNS - x - 1), false);
// 	}
//   }
// }

